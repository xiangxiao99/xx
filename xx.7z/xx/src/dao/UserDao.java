package dao;

import pojo.User;

public interface UserDao {

    int find(String account, String psw);

    boolean insert(String account, String psw);

    boolean updateUserInfo(User user);

    User getUserByAccount(String account);

}
