package dao.impl;

import dao.GoodsDao;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import pojo.Goods;
import util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author haya
 */
public class GoodsDaoImpl implements GoodsDao {
    @Override
    public Map<Integer, Goods> getAll() {
        Connection con = DBUtil.getConnection();
        String sql = "SELECT * FROM goods";
        PreparedStatement prst = null;
        ResultSet res = null;
        Map<Integer, Goods> map = new HashMap<>();
        try {
            prst = con.prepareStatement( sql );
            res = prst.executeQuery();
            while (res.next()) {
                Goods goods = new Goods();
                goods.setId( res.getInt( "id" ) );
                goods.setName( res.getString( "name" ) );
                goods.setPrice( res.getDouble( "price" ) );
                goods.setStock( res.getInt( "stock" ) );
                goods.setClass_id( res.getInt( "class_id" ) );
                map.put( goods.getId(), goods );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                res.close();
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return map;
    }

    @Override
    public Goods getGoodsById(String id) {
        QueryRunner runner = new QueryRunner();
        BasicDataSource dataSource = DBUtil.getDataSource();
        Connection connection = null;
        Goods res = null;
        try {
            connection = dataSource.getConnection();
            String sql = "select * from goods where id = ?";
            res = runner.query( connection, sql, new BeanHandler<>( Goods.class ), id );
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return res;
    }

    @Override
    public Map<String, Object> getGoodsByName(String name) {
        QueryRunner runner = new QueryRunner();
        BasicDataSource dataSource = DBUtil.getDataSource();
        Connection connection = null;
        Map<String, Object> res = null;
        try {
            connection = dataSource.getConnection();
            String sql = "select * from goods where name like ?";
            List<Map<String, Object>> query = runner.query( connection, sql, new MapListHandler(), name );
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(res);
        return res;
    }

    @Override
    public Map<Integer, Goods> getGoodsByAccount(String account) {
        Connection con = DBUtil.getConnection();
        String sql = "SELECT * FROM goods WHERE seller = ?";
        PreparedStatement prst = null;
        ResultSet res = null;
        Map<Integer, Goods> map = new HashMap<>();
        try {
            prst = con.prepareStatement( sql );
            prst.setString( 1, account );
            res = prst.executeQuery();
            while (res.next()) {
                Goods goods = new Goods();
                goods.setId( res.getInt( "id" ) );
                goods.setName( res.getString( "name" ) );
                goods.setPrice( res.getDouble( "price" ) );
                goods.setStock( res.getInt( "stock" ) );
                goods.setClass_id( res.getInt( "class_id" ) );
                goods.setSeller( res.getString( "seller" ) );
                map.put( goods.getId(), goods );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                res.close();
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return map;
    }

    @Override
    public int insert(Goods goods) {
        Connection con = DBUtil.getConnection();
        String sql = "INSERT INTO goods VALUES(?,?,?,?,?,?)";
        PreparedStatement prst = null;
        int res = 0;
        try {
            prst = con.prepareStatement( sql );
            prst.setInt( 1, goods.getId() );
            prst.setString( 2, goods.getName() );
            prst.setInt( 3, goods.getStock() );
            prst.setDouble( 4, goods.getPrice() );
            prst.setInt( 5, goods.getClass_id() );
            prst.setString( 6, goods.getSeller() );
            res = prst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return res;
    }

    @Override
    public int romove(int id) {
        Connection con = DBUtil.getConnection();
        String sql = "DELETE FROM goods WHERE id = ?";
        PreparedStatement prst = null;
        int res = 0;
        try {
            prst = con.prepareStatement( sql );
            prst.setInt( 1, id );
            res = prst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return res;
    }

    @Override
    public int update(Goods goods) {

        return 0;
    }
}
