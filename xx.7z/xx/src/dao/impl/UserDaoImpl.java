package dao.impl;

import dao.UserDao;
import pojo.User;
import util.DBUtil;

import java.sql.*;

public class UserDaoImpl implements UserDao {

    @Override
    public int find(String account, String psw) {
        Connection con = DBUtil.getConnection();
        String sql = "SELECT role FROM user WHERE account = ? and password = ?";
        PreparedStatement prst = null;
        ResultSet rst = null;
        int role = -1;
        try {
            prst = con.prepareStatement( sql );
            prst.setString( 1, account );
            prst.setString( 2, psw );
            rst = prst.executeQuery();
            while (rst.next()) {
                role = rst.getInt( "role" );
                System.out.println(role);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                rst.close();
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return role;
    }

    @Override
    public boolean insert(String account, String psw) {
        Connection con = DBUtil.getConnection();
        String sql = "INSERT INTO user(account,password) VALUES (?,?)";
        PreparedStatement prst = null;
        int i=0;
        try {
            prst = con.prepareStatement(sql);
            prst.setString( 1, account );
            prst.setString( 2, psw );
            i = prst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i>0;
    }

    @Override
    public boolean updateUserInfo(User user) {
        Connection con = DBUtil.getConnection();
        String sql = "UPDATE user SET "
                + "age = ?,"
                + "sex = ?,"
                + "address = ?,"
                + "phone = ?,"
                + "email = ?,"
                + "degree = ?,"
                + "school = ?,"
                + "master = ? "
                + "WHERE account = ?";
        PreparedStatement prst = null;
        int i=0;
        try {
            prst = con.prepareStatement( sql );
            prst.setInt( 1, user.getAge() );
            prst.setString( 2, user.getSex() );
            prst.setString( 3, user.getAddress() );
            prst.setString( 4, user.getPhone() );
            prst.setString( 5, user.getEmail() );
            prst.setString( 6, user.getDegree() );
            prst.setString( 7, user.getSchool() );
            prst.setString( 8, user.getMaster() );
            prst.setString( 9, user.getAccount() );
            i = prst.executeUpdate();
        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i > 0;
    }

    @Override
    public User getUserByAccount(String account) {
        Connection con = DBUtil.getConnection();
        String sql = "SELECT account,"
                + "name, "
                + "age, "
                + "sex,"
                + "address,"
                + "phone,"
                + "email,"
                + "degree,"
                + "school,"
                + "master"+
        " FROM user WHERE account = ? ";
        PreparedStatement prst = null;
        ResultSet rst = null;
        User user = new User();
        try {
            prst = con.prepareStatement( sql );
            prst.setString( 1, account );
            rst = prst.executeQuery();
            while (rst.next()) {
                user.setAccount( rst.getString( 1 ) );
                user.setName( rst.getString( 2 ) );
                user.setAge( rst.getInt( 3 ) );
                user.setSex( rst.getString( 4 ) );
                user.setAddress( rst.getString( 5 ) );
                user.setPhone( rst.getString( 6 ) );
                user.setEmail( rst.getString( 7 ) );
                user.setDegree( rst.getString( 8 ) );
                user.setSchool( rst.getString( 9 ) );
                user.setMaster( rst.getString( 10 ) );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                rst.close();
                prst.close();
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return user;
    }

}

