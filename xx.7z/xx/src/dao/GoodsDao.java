package dao;

import pojo.Goods;

import java.util.List;
import java.util.Map;

public interface GoodsDao {
    Map<Integer,Goods> getAll();

    Goods getGoodsById(String id);

    Map<String, Object> getGoodsByName(String name);

    Map<Integer,Goods> getGoodsByAccount(String name);

    int insert(Goods goods);

    int romove(int id);

    int update(Goods goods);
}
