package filter;


import util.Utils;

import javax.rmi.CORBA.Util;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author haya
 */
@WebFilter(urlPatterns = "/*")
public class AllFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) {
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String path = request.getServletPath();
        Cookie[] cookies = request.getCookies();
        if ("/login.jsp".equals( path ) ) {
            filterChain.doFilter( request, response );
            return;
        }
        if (cookies != null) {
            String acc = null, psw = null;
            acc = Utils.getCookieVal( "_acc", cookies );
            psw = Utils.getCookieVal( "_psw", cookies );
            if (acc != null && psw != null) {
                HttpSession session = request.getSession();
                if (session.getAttribute( "loginTime" ) == null) {
                    session.setAttribute( "acc", acc );
                    session.setAttribute( "psw", psw );
                    session.setAttribute( "loginTime", Utils.getTime() );
                }
            }
        }
        filterChain.doFilter( request, response );
    }

    @Override
    public void destroy() {

    }
}
