package filter;

import util.Utils;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author haya
 */
@WebFilter(urlPatterns = {"/login.jsp"})
public class LoginFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) {
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        synchronized (LoginFilter.class) {
            HttpServletRequest request = (HttpServletRequest) servletRequest;
            HttpServletResponse response = (HttpServletResponse) servletResponse;
            //读取cookie
            Cookie[] cookies = request.getCookies();
            String acc = null, psw = null;
            System.out.println(request.getServletPath());
            if (cookies != null) {
                acc = Utils.getCookieVal( "_acc", cookies );
                psw = Utils.getCookieVal( "_psw", cookies );
            }
            if (acc != null && psw != null) {
                HttpSession session = request.getSession();
                session.setAttribute( "acc", acc );
                session.setAttribute( "psw", psw );
                session.setAttribute( "loginTime", Utils.getTime() );
                response.sendRedirect( "/goods" );
                return;
            }
            filterChain.doFilter( request,response );
        }
    }

    @Override
    public void destroy() {
    }

}
