package util;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.pool.impl.GenericObjectPool;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author haya
 */
public class DBUtil {

    private static BasicDataSource dataSource;

    public static Connection getConnection() {
        Properties config = null;
        try {
            config = Utils.loadProperties( "db.properties" );
        } catch (IOException e) {
            e.printStackTrace();
        }
        String driver = config.getProperty( "driver" );
        String url = config.getProperty( "url" );
        String name = config.getProperty( "name" );
        String password = config.getProperty( "password" );
        Connection connection = null;
        try {
            Class.forName( driver );
            connection = DriverManager.getConnection( url, name, password );
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static BasicDataSource getDataSource() {

            dataSource = new BasicDataSource();
            Properties properties = null;
            try {
                properties = Utils.loadProperties( "db.properties" );
            } catch (IOException e) {
                e.printStackTrace();
            }
            // 基础配置
            dataSource.setUsername( properties.getProperty( "name" ) );
            dataSource.setPassword( properties.getProperty( "password" ) );
            dataSource.setUrl( properties.getProperty( "url" ) );
            dataSource.setDriverClassName( properties.getProperty( "drive" ) );
            // 连接池的相关配置，这部分的默认配置完全由apache-commons-pool组件提供
            dataSource.setInitialSize( GenericObjectPool.DEFAULT_MIN_IDLE );
            dataSource.setMaxActive( GenericObjectPool.DEFAULT_MAX_ACTIVE );
            dataSource.setMaxIdle( GenericObjectPool.DEFAULT_MAX_ACTIVE );
            dataSource.setMinIdle( GenericObjectPool.DEFAULT_MIN_IDLE );
            dataSource.setMaxWait( GenericObjectPool.DEFAULT_MAX_WAIT );
            dataSource.setTestOnBorrow( GenericObjectPool.DEFAULT_TEST_ON_BORROW );
            dataSource.setTestOnReturn( GenericObjectPool.DEFAULT_TEST_ON_RETURN );
            dataSource.setTestWhileIdle( GenericObjectPool.DEFAULT_TEST_WHILE_IDLE );

        return dataSource;
    }
}
