package util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author haya
 */
public class Utils {

    public static String getTime() {
        final SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.applyPattern("yyyy-MM-dd HH:mm:ss a");
        return sdf.format( new Date() );
    }

    public static Cookie newCookie(String key, String val, int age) {
        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        Cookie cookie = null;
        try {
            cookie = new Cookie( key, val );
            cookie.setMaxAge( age );
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            lock.unlock();
        }
        return cookie;
    }

    public static String getCookieVal(String key, HttpServletRequest request) {
        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        String res = null;
        try {
            if (key == null || "".equals( key.trim() )) {
                throw new Exception( "空Key" );
            }
            Cookie[] cookies = request.getCookies();
            if (null == cookies){
                throw new Exception( "空cookies" );
            }
            res = getCookieVal( key, cookies );
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
        return res;
    }

    public static String getCookieVal(String key, Cookie[] cookies) {
        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        String res = null;
        try {
            if (key == null || "".equals( key.trim() )) {
                throw new Exception( "空Key" );
            }
            if (null == cookies){
                throw new Exception( "空cookies" );
            }
            for (Cookie c : cookies) {
                if (key.equals( c.getName() )) {
                    res = c.getValue();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
        return res;
    }

    public static Properties loadProperties(String fileName) throws IOException {
        Properties properties = new Properties();
        String resource = Utils.class.getClassLoader().getResource( fileName ).getPath();
        System.out.println( resource );
        FileInputStream in = new FileInputStream( resource);
        properties.load(in);
        return properties;
    }
}
