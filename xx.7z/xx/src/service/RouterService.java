package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface RouterService {

    void loginRouter(HttpServletRequest request, HttpServletResponse response,String acc, int role) throws IOException;

    /**
     *
     * @param account
     * @param role
     */
    void putRole(String account, int role);
}
