package service;

import pojo.Goods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * @author haya
 */
public interface GoodsService {
    /**
     * 获取所有商品
     * @param req
     * @param resp
     * @return
     * @throws IOException
     */
    Map<Integer, Goods> getAll(HttpServletRequest req, HttpServletResponse resp) throws IOException;

    /**
     * 根据商品名称获取商品
     * @param req
     * @param resp
     * @param name
     * @return
     * @throws IOException
     */
    Map<String, Object> getGoodsByName(HttpServletRequest req, HttpServletResponse resp, String name) throws IOException;

    /**
     * 根据卖家账号获取其发布的商品
     * @param req
     * @param resp
     * @param account
     * @return
     * @throws IOException
     */
    Map<Integer, Goods> getGoodsByAccount(HttpServletRequest req, HttpServletResponse resp,String account) throws IOException;

    Goods getGoodsById(String id);

    boolean update(Goods goods);
}
