package service;

import pojo.User;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface UserService {
    /** 登录
     * @param request
     * @param response
     * @param account
     * @param psw
     * @return -1 登录失败；1 用户；2 卖家
     * @throws IOException
     */
    int login(HttpServletRequest request, HttpServletResponse response, String account, String psw) throws IOException;

    boolean register(String acc, String psw);

    boolean update(User user);

}
