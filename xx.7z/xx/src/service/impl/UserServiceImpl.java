package service.impl;

import dao.UserDao;
import dao.impl.UserDaoImpl;
import pojo.User;
import service.UserService;
import util.Utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author haya
 */
public class UserServiceImpl implements UserService {
    private UserDao userDao = new UserDaoImpl();
    @Override
    public int login(HttpServletRequest request, HttpServletResponse response, String account, String psw) throws IOException {
        int role = -1;
        //登录失败
        if (account == null || "".equals( account.trim() )) {
            return -1;
        }
        //登录失败
        if (psw == null || "".equals( psw.trim() )) {
            return -1;
        }
        //登录失败
        if (-1 == (role = userDao.find( account, psw ))) {
            return -1;
        }
        //登陆成功
        String[] values = request.getParameterValues( "checkbox" );
        //cookie
        if (values != null && "seven".equals( values[0] )) {
            Cookie c1 = Utils.newCookie( "_acc", account, 60 * 60 * 24 * 7 );
            Cookie c2 = Utils.newCookie( "_psw", psw, 60 * 60 * 24 * 7 );
            response.addCookie(c1);
            response.addCookie(c2);
        }
        HttpSession session = request.getSession();
        session.setAttribute( "loginTime", Utils.getTime() );
        session.setAttribute( "acc",account );
        session.setAttribute( "psw",psw );
        session.setAttribute( "user",  userDao.getUserByAccount( account ) );

        return role;
    }

    @Override
    public boolean register(String acc, String psw) {
        return userDao.insert( acc, psw );
    }

    @Override
    public boolean update(User user) {
        return userDao.updateUserInfo( user );
    }

}
