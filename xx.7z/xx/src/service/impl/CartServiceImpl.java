package service.impl;

import pojo.Goods;
import service.CartService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author haya
 */
public class CartServiceImpl implements CartService {
    @Override
    public void addGoodsToCart(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        String id = req.getParameter( "add_id" );
        Map<Integer, Goods> all = (Map<Integer, Goods>) session.getAttribute( "all" );
        Map<Integer, Goods> cart = (Map<Integer, Goods>) session.getAttribute( "cart" );
        if (cart == null) {
            cart = new HashMap<>(10);
        }
        Goods goods = all.get( Integer.parseInt( id ) );
        cart.put( goods.getId(), goods );
        session.setAttribute( "cart", cart );

    }

    @Override
    public void delGoodsFromCart(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        Map<Integer, Goods> cart = (Map<Integer, Goods>) session.getAttribute( "cart" );
        cart.remove( Integer.parseInt( req.getParameter( "del_id" ) ) );
        session.setAttribute( "cart",cart );
    }


}
