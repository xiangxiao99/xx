package service.impl;

import service.RouterService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;

/**
 * @author haya
 */
public class RouterServiceImpl implements RouterService {
    private static HashMap<String, Integer> rolePoll = new HashMap<>();

    @Override
    public void loginRouter(HttpServletRequest request, HttpServletResponse response, String account, int role) throws IOException {
        HttpSession session = request.getSession();
        session.setAttribute( "role", role );
        putRole( account, role );
        switch (role) {
            case -1:
                response.sendRedirect( "login.jsp" );
                break;
            case 1:
                response.sendRedirect( "/goods" );
                break;
            case 2:
                response.sendRedirect( "/goods" );
                break;
            default:
                response.sendRedirect( "/goods" );
                break;
        }
    }

    @Override
    public void putRole(String account, int role) {
        rolePoll.put( account, role );
    }
}
