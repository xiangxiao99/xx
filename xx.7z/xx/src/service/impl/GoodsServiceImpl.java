package service.impl;

import dao.GoodsDao;
import dao.impl.GoodsDaoImpl;
import pojo.Goods;
import service.GoodsService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

/**
 * @author haya
 */
public class GoodsServiceImpl implements GoodsService {
    private GoodsDao goodsDao = new GoodsDaoImpl();

    @Override
    public Map<Integer, Goods> getAll(HttpServletRequest req, HttpServletResponse resp) {
        Map<Integer, Goods> all = goodsDao.getAll();
        HttpSession session = req.getSession();
        session.setAttribute( "all", all );
        return all;
    }

    @Override
    public Map<String, Object> getGoodsByName(HttpServletRequest req, HttpServletResponse resp, String name) {
        HttpSession session = req.getSession();
        Map<String, Object> res = goodsDao.getGoodsByName( name );
        session.setAttribute( "all", res );
        return res;
    }

    @Override
    public Map<Integer, Goods> getGoodsByAccount(HttpServletRequest req, HttpServletResponse resp, String account) throws IOException {
        HttpSession session = req.getSession();
        Map<Integer, Goods> res = goodsDao.getGoodsByAccount( account );
        session.setAttribute( "myGoods", res );
        return null;
    }

    @Override
    public Goods getGoodsById(String id) {
        return goodsDao.getGoodsById( id );
    }

    @Override
    public boolean update(Goods goods) {
        return  goodsDao.update( goods )>0;
    }

}
