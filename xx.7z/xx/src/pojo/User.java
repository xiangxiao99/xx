package pojo;

public class User {

    private String account;
    private String password;
    private String name;
    private int age;
    private String sex;
    private String address;
    private String phone;
    private String email;
    private String degree;
    private String school;
    private String master;
    private int role;

    public String getAccount() {
        return account;
    }

    public User setAccount(String account) {
        this.account = account;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public User setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getName() {
        return name;
    }

    public User setName(String name) {
        this.name = name;
        return this;
    }

    public int getAge() {
        return age;
    }

    public User setAge(int age) {
        this.age = age;
        return this;
    }

    public String getSex() {
        return sex;
    }

    public User setSex(String sex) {
        this.sex = sex;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public User setAddress(String address) {
        this.address = address;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public User setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public User setEmail(String email) {
        this.email = email;
        return this;
    }

    public String getDegree() {
        return degree;
    }

    public User setDegree(String degree) {
        this.degree = degree;
        return this;
    }

    public String getSchool() {
        return school;
    }

    public User setSchool(String school) {
        this.school = school;
        return this;
    }

    public String getMaster() {
        return master;
    }

    public User setMaster(String master) {
        this.master = master;
        return this;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder( "{" );
        sb.append( "\"account\":\"" )
                .append( account ).append( '\"' );
        sb.append( ",\"password\":\"" )
                .append( password ).append( '\"' );
        sb.append( ",\"name\":\"" )
                .append( name ).append( '\"' );
        sb.append( ",\"age\":" )
                .append( age );
        sb.append( ",\"sex\":\"" )
                .append( sex ).append( '\"' );
        sb.append( ",\"address\":\"" )
                .append( address ).append( '\"' );
        sb.append( ",\"phone\":\"" )
                .append( phone ).append( '\"' );
        sb.append( ",\"email\":\"" )
                .append( email ).append( '\"' );
        sb.append( ",\"degree\":\"" )
                .append( degree ).append( '\"' );
        sb.append( ",\"school\":\"" )
                .append( school ).append( '\"' );
        sb.append( ",\"master\":\"" )
                .append( master ).append( '\"' );
        sb.append( '}' );
        return sb.toString();
    }
}
