package pojo;

import java.util.StringJoiner;

public class Goods {
    private int id;
    private String name;
    private Double price;
    private int stock;
    private int class_id;
    private String seller;

    public Goods() {
    }

    public Goods(int id, String name, Double price, int stock) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public int getId() {
        return id;
    }

    public Goods setId(int id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Goods setName(String name) {
        this.name = name;
        return this;
    }

    public Double getPrice() {
        return price;
    }

    public Goods setPrice(Double price) {
        this.price = price;
        return this;
    }

    public int getStock() {
        return stock;
    }

    public Goods setStock(int stock) {
        this.stock = stock;
        return this;
    }

    public int getClass_id() {
        return class_id;
    }

    public Goods setClass_id(int class_id) {
        this.class_id = class_id;
        return this;
    }

    public String getSeller() {
        return seller;
    }

    public Goods setSeller(String seller) {
        this.seller = seller;
        return this;
    }

    @Override
    public String toString() {
        return new StringJoiner( ", ", Goods.class.getSimpleName() + "[", "]" )
                .add( "id=" + id )
                .add( "name='" + name + "'" )
                .add( "price=" + price )
                .add( "stock=" + stock )
                .add( "class_id=" + class_id )
                .toString();
    }
}
