package controller;


import pojo.Goods;
import service.GoodsService;
import service.impl.GoodsServiceImpl;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author haya
 */
@WebServlet(name = "goods", urlPatterns = "/goods")
public class GoodsController extends HttpServlet {

    private GoodsService goodsService = new GoodsServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (null != req.getParameter( "search" )) {
            String search = req.getParameter( "search" );
            goodsService.getGoodsByName( req, resp, search );
            resp.sendRedirect( "/index.jsp" );
            return;
        } else if (null != req.getParameter( "mygoods" )) {
            String account = req.getParameter( "mygoods" );
            goodsService.getGoodsByAccount( req, resp, account );
            resp.sendRedirect( "/sellerIndex.jsp" );
            return;
        } else if (null != req.getParameter( "edit" )) {
            String goodsId = req.getParameter( "edit" );
            HttpSession session = req.getSession();
            session.setAttribute( "edit", goodsService.getGoodsById( goodsId ) );
            resp.sendRedirect( "/editGoods.jsp" );
        } else if (null != req.getParameter( "edited" )) {
            int id = Integer.parseInt( req.getParameter( "edited" ) );
            String name = req.getParameter( "name" );
            int stock = Integer.parseInt( req.getParameter( "stock" ) );
            Double price = Double.parseDouble( req.getParameter( "price" ) );
            goodsService.update( new Goods( id, name,price,stock ) );
            resp.sendRedirect( "/sellerIndex.jsp" );
        } else {
            goodsService.getAll( req, resp );
            resp.sendRedirect( "/index.jsp" );
            return;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        doGet( req, resp );
    }
}
