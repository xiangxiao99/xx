package controller;

import service.RouterService;
import service.UserService;
import service.impl.RouterServiceImpl;
import service.impl.UserServiceImpl;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author haya
 */
@WebServlet(name = "LoginController", urlPatterns = "/LoginController")
public class LoginController extends HttpServlet {
    private UserService userService = new UserServiceImpl();
    private RouterService routerService = new RouterServiceImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String acc = request.getParameter( "acc" );
        String psw = request.getParameter( "psw" );
        if (null != request.getParameter( "login" )) {
            int role = userService.login( request, response, acc, psw );
            routerService.loginRouter( request, response, acc, role );
        } else if (null != request.getParameter( "register" )) {
            userService.register( acc, psw );
            response.sendRedirect( "login.jsp" );
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost( request, response );
    }
}
