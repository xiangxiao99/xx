package controller;

import service.CartService;
import service.impl.CartServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author haya
 */
@WebServlet(name = "cart", urlPatterns = "/cart")
public class CartController extends HttpServlet {
    private CartService cartService = new CartServiceImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet( req, resp );
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println( req.getParameter( "add_id" ) );
        System.out.println( req.getParameter( "del_id" ) );
        if (null != req.getParameter( "add_id" )) {
            cartService.addGoodsToCart( req, resp );
            resp.sendRedirect( "/goods" );
        } else if (null != req.getParameter( "del_id" )) {
            cartService.delGoodsFromCart( req, resp );
            resp.sendRedirect( "/cart.jsp" );
        }
        
    }
}
